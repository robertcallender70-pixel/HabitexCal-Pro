import React from 'react';
import type { Project, Activity, Material, LaborItem, BudgetItem, Transaction, PredefinedLaborActivity } from '../types';
import { ActivityType, TransactionType } from '../types';
import {
    getProjects, addProject, updateProject, deleteProject, getActivities,
    addActivity, updateActivity, deleteActivity, getMaterialPrices, setMaterialPrice,
    getLaborItems, addLaborItem, updateLaborItem, deleteLaborItem,
    getBudgetItems, addBudgetItem, updateBudgetItem, deleteBudgetItem,
    getTransactions, addTransaction, updateTransaction, deleteTransaction,
    exportAllData, importAllData, getDataLibrary, updateDataLibraryItem
} from '../services/database';
import { calculateMaterials } from '../services/calculations';
import { exportProjectToPDF } from '../services/pdf';
import Modal from './Modal';
import ActivityForm from './ActivityForm';
import AddLaborItemModal from './AddLaborItemModal';
import BudgetItemModal from './BudgetItemModal';
import TransactionModal from './TransactionModal';
import FinancialChart from './FinancialChart';
import DataLibrary from './DataLibrary';
import { 
    PlusIcon, TrashIcon, PencilIcon, ChevronDownIcon, ArrowLeftIcon, PdfIcon,
    ArrowDownTrayIcon, ArrowUpTrayIcon, BanknotesIcon, ArrowTrendingUpIcon,
    ArrowTrendingDownIcon, ScaleIcon, CogIcon
} from '../constants';


const ProjectManager: React.FC = () => {
    // State management
    const [projects, setProjects] = React.useState<Project[]>([]);
    const [selectedProject, setSelectedProject] = React.useState<Project | null>(null);
    const [activities, setActivities] = React.useState<Activity[]>([]);
    const [laborItems, setLaborItems] = React.useState<LaborItem[]>([]);
    const [budgetItems, setBudgetItems] = React.useState<BudgetItem[]>([]);
    const [transactions, setTransactions] = React.useState<Transaction[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [materialPrices, setMaterialPrices] = React.useState<Record<string, number>>({});
    const [projectCosts, setProjectCosts] = React.useState<Record<number, number>>({});
    const [currentView, setCurrentView] = React.useState<'financials' | 'materials' | 'labor' | 'budget'>('financials');
    const [exchangeRate, setExchangeRate] = React.useState<number>(() => {
        const savedRate = localStorage.getItem('exchangeRateCUPtoUSD');
        return savedRate ? parseFloat(savedRate) : 380;
    });
    const [displayCurrency, setDisplayCurrency] = React.useState<'CUP' | 'USD'>('CUP');
    const [libraryData, setLibraryData] = React.useState<any>(null);


    // Modal states
    const [isProjectModalOpen, setIsProjectModalOpen] = React.useState(false);
    const [editingProject, setEditingProject] = React.useState<Project | null>(null);
    const [newProjectName, setNewProjectName] = React.useState('');

    const [isActivityModalOpen, setIsActivityModalOpen] = React.useState(false);
    const [editingActivity, setEditingActivity] = React.useState<Activity | null>(null);
    const [selectedActivityType, setSelectedActivityType] = React.useState<ActivityType | null>(null);

    const [isLaborItemModalOpen, setIsLaborItemModalOpen] = React.useState(false);
    const [editingLaborItem, setEditingLaborItem] = React.useState<LaborItem | null>(null);
    
    const [isBudgetItemModalOpen, setIsBudgetItemModalOpen] = React.useState(false);
    const [editingBudgetItem, setEditingBudgetItem] = React.useState<BudgetItem | null>(null);

    const [isTransactionModalOpen, setIsTransactionModalOpen] = React.useState(false);
    const [editingTransaction, setEditingTransaction] = React.useState<Transaction | null>(null);

    const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false);
    const [itemToDelete, setItemToDelete] = React.useState<{ type: 'project' | 'activity' | 'labor' | 'budget' | 'transaction'; id: number } | null>(null);

    const [isImportConfirmModalOpen, setIsImportConfirmModalOpen] = React.useState(false);
    const [dataToImport, setDataToImport] = React.useState<any>(null);
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    
    const [isDataLibraryOpen, setIsDataLibraryOpen] = React.useState(false);

    const getActivitySubtitle = (activity: Activity): string => {
        if (activity.type === ActivityType.REVESTIMIENTO && activity.inputs.tiposRevestimiento && libraryData) {
             const selectedLayers = Object.keys(activity.inputs.tiposRevestimiento)
                .filter(key => activity.inputs.tiposRevestimiento[key])
                .map(layerId => {
                    const layerData = libraryData.morteros_revestimiento.find((r: any) => r.id === layerId);
                    return layerData ? layerData.nombre : null;
                })
                .filter(Boolean);

            return selectedLayers.length > 0 ? selectedLayers.join(', ') : activity.type;
        }
        if (activity.type === ActivityType.ESTRUCTURA_PLADUR) {
            const type = activity.inputs.tipoEstructura === 'pared' ? 'Pared' : 'Techo';
            const insulation = activity.inputs.incluirAislamiento ? ' con Aislante' : '';
            return `${type}${insulation}`;
        }
        return activity.type;
    };

    // Data loading effects
    const loadInitialData = React.useCallback(async () => {
        setIsLoading(true);
        try {
            const [projectsFromDB, pricesFromDB, libData] = await Promise.all([
                getProjects(),
                getMaterialPrices(),
                getDataLibrary()
            ]);
            
            setLibraryData(libData);

            const validProjects = projectsFromDB.filter(p => p.createdAt && !isNaN(new Date(p.createdAt).getTime()));
            setProjects(validProjects.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));

            const priceMap = pricesFromDB.reduce((acc: Record<string, number>, item: { name: string, unit: string, price: number }) => {
                acc[`${item.name}-${item.unit}`] = item.price;
                return acc;
            }, {});
            setMaterialPrices(priceMap);

        } catch (error) {
            console.error("Failed to load initial data:", error);
        } finally {
            setIsLoading(false);
        }
    }, []);

    const loadProjectData = React.useCallback(async () => {
        if (!selectedProject) return;
        setIsLoading(true);
        try {
            const [activitiesFromDB, laborItemsFromDB, budgetItemsFromDB, transactionsFromDB] = await Promise.all([
                getActivities(selectedProject.id!),
                getLaborItems(selectedProject.id!),
                getBudgetItems(selectedProject.id!),
                getTransactions(selectedProject.id!),
            ]);

            setActivities(activitiesFromDB);
            setLaborItems(laborItemsFromDB);
            setBudgetItems(budgetItemsFromDB);
            setTransactions(transactionsFromDB.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        } catch (error) {
            console.error(`Failed to load data for project ${selectedProject.id}:`, error);
        } finally {
            setIsLoading(false);
        }
    }, [selectedProject]);

    React.useEffect(() => {
        loadInitialData();
    }, [loadInitialData]);

    React.useEffect(() => {
        if (selectedProject) {
            loadProjectData();
        } else {
            // When returning to project list, clear the specific project data
            setActivities([]);
            setLaborItems([]);
            setBudgetItems([]);
            setTransactions([]);
        }
    }, [selectedProject, loadProjectData]);
    
    const updateCostForProject = React.useCallback(async (projectId: number) => {
        if (!projectId) return;

        const projectActivities = await getActivities(projectId);
        const projectLaborItems = await getLaborItems(projectId);
        const projectBudgetItems = await getBudgetItems(projectId);

        const materialTotal = projectActivities.reduce((total, activity) => {
            return total + activity.results.reduce((activityTotal, material) => {
                const price = materialPrices[`${material.name}-${material.unit}`] || 0;
                return activityTotal + (material.quantity * price);
            }, 0);
        }, 0);

        const laborTotal = projectLaborItems.reduce((total, item) => {
            return total + (item.quantity * item.unitPrice);
        }, 0);

        const budgetTotal = projectBudgetItems.reduce((total, item) => {
            return total + item.cost;
        }, 0);

        const totalCost = materialTotal + laborTotal + budgetTotal;

        setProjectCosts(prev => ({
            ...prev,
            [projectId]: totalCost
        }));
    }, [materialPrices]);

    React.useEffect(() => {
        const calculateAllCosts = async () => {
            if (projects.length > 0 && Object.keys(materialPrices).length > 0) {
                for (const project of projects) {
                    if (project.id) {
                       await updateCostForProject(project.id);
                    }
                }
            }
        };
        calculateAllCosts();
    }, [projects, materialPrices, updateCostForProject]);


    // Project handlers
    const handleOpenProjectModal = (project: Project | null) => {
        setEditingProject(project);
        setNewProjectName(project ? project.name : '');
        setIsProjectModalOpen(true);
    };

    const handleSaveProject = async () => {
        if (!newProjectName.trim()) return;
        if (editingProject) {
            await updateProject({ ...editingProject, name: newProjectName });
        } else {
            await addProject({ name: newProjectName, createdAt: new Date() });
        }
        await loadInitialData();
        setIsProjectModalOpen(false);
        setNewProjectName('');
        setEditingProject(null);
    };

    const handleSelectProject = (project: Project) => {
        setSelectedProject(project);
        setCurrentView('financials'); // Reset to default view on project change
    };

    // Activity handlers
    const handleOpenActivityModal = (type: ActivityType, activity: Activity | null) => {
        setSelectedActivityType(type);
        setEditingActivity(activity);
        setIsActivityModalOpen(true);
    };
    
    // Labor Item Handlers
    const handleSaveLaborItem = async (item: Omit<LaborItem, 'id' | 'projectId'>) => {
        if (!selectedProject) return;
        if(editingLaborItem) {
            await updateLaborItem({ ...editingLaborItem, ...item });
        } else {
            await addLaborItem({ ...item, projectId: selectedProject.id! });
        }
        await loadProjectData();
        await updateCostForProject(selectedProject.id!);
        setIsLaborItemModalOpen(false);
        setEditingLaborItem(null);
    };

     // Combined Labor and Material Handler
    const handleSaveLaborAndAddMaterials = async (item: Omit<LaborItem, 'id' | 'projectId'>, materialType: ActivityType) => {
        if (!selectedProject) return;

        // 1. Save the labor item
        await addLaborItem({ ...item, projectId: selectedProject.id! });

        // 2. Close the current modal and open the material one
        closeModals();
        handleOpenActivityModal(materialType, null);

        // 3. Refresh project data in the background
        await loadProjectData();
        await updateCostForProject(selectedProject.id!);
    };

    // Budget Item Handlers
    const handleSaveBudgetItem = async (item: Omit<BudgetItem, 'id' | 'projectId'>) => {
        if (!selectedProject) return;
        if(editingBudgetItem) {
            await updateBudgetItem({ ...editingBudgetItem, ...item });
        } else {
            await addBudgetItem({ ...item, projectId: selectedProject.id! });
        }
        await loadProjectData();
        await updateCostForProject(selectedProject.id!);
        setIsBudgetItemModalOpen(false);
        setEditingBudgetItem(null);
    };
    
    // Transaction Handlers
    const handleSaveTransaction = async (item: Omit<Transaction, 'id' | 'projectId'>) => {
        if (!selectedProject) return;
        if (editingTransaction) {
            await updateTransaction({ ...editingTransaction, ...item });
        } else {
            await addTransaction({ ...item, projectId: selectedProject.id! });
        }
        await loadProjectData();
        setIsTransactionModalOpen(false);
        setEditingTransaction(null);
    };

    const handleSaveActivity = async (inputs: Record<string, any>) => {
        if (!selectedProject || !selectedActivityType) return;
        
        const parsedInputs = { ...inputs };
        const numericKeysFromSelect = [
            'resistencia', 'tipoBarraPlato', 'tipoBarraPedestal', 'tipoBarraArosPedestal',
            'tipoBarra', 'tipoBarraAros'
        ];

        for (const key of numericKeysFromSelect) {
            if (parsedInputs[key] && typeof parsedInputs[key] === 'string') {
                const num = parseInt(parsedInputs[key], 10);
                if (!isNaN(num)) {
                    parsedInputs[key] = num;
                }
            }
        }
        
        const results = await calculateMaterials(selectedActivityType, parsedInputs);
        
        if (editingActivity) {
            const updatedActivity: Activity = {
                ...editingActivity,
                name: (selectedActivityType === ActivityType.CUSTOM && inputs.customName) ? inputs.customName : editingActivity.name,
                inputs: parsedInputs,
                results,
            };
            await updateActivity(updatedActivity);
        } else {
            const newActivity: Activity = {
                projectId: selectedProject.id!,
                type: selectedActivityType,
                name: (selectedActivityType === ActivityType.CUSTOM && inputs.customName) ? inputs.customName : `${selectedActivityType} - ${new Date().toLocaleDateString()}`,
                inputs: parsedInputs,
                results,
            };
            await addActivity(newActivity);
        }
        await loadProjectData();
        await updateCostForProject(selectedProject.id!);
        setIsActivityModalOpen(false);
        setEditingActivity(null);
        setSelectedActivityType(null);
    };

    // Delete handlers
    const handleOpenDeleteModal = (type: 'project' | 'activity' | 'labor' | 'budget' | 'transaction', id: number) => {
        setItemToDelete({ type, id });
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = async () => {
        if (!itemToDelete) return;
        const currentProjectId = selectedProject?.id;
        
        if (itemToDelete.type === 'project') {
            await deleteProject(itemToDelete.id);
            await loadInitialData();
            setSelectedProject(null);
        } else if (itemToDelete.type === 'activity') {
            await deleteActivity(itemToDelete.id);
        } else if (itemToDelete.type === 'labor') {
            await deleteLaborItem(itemToDelete.id);
        } else if (itemToDelete.type === 'budget') {
            await deleteBudgetItem(itemToDelete.id);
        } else if (itemToDelete.type === 'transaction') {
            await deleteTransaction(itemToDelete.id);
        }
        
        if (currentProjectId && itemToDelete.type !== 'project') {
            await loadProjectData();
            await updateCostForProject(currentProjectId);
        }

        setIsDeleteModalOpen(false);
        setItemToDelete(null);
    };

    const closeModals = () => {
        setIsProjectModalOpen(false);
        setIsActivityModalOpen(false);
        setIsDeleteModalOpen(false);
        setIsLaborItemModalOpen(false);
        setIsBudgetItemModalOpen(false);
        setIsTransactionModalOpen(false);
        setIsImportConfirmModalOpen(false);
        setIsDataLibraryOpen(false);
        setEditingProject(null);
        setEditingActivity(null);
        setSelectedActivityType(null);
        setEditingLaborItem(null);
        setEditingBudgetItem(null);
        setEditingTransaction(null);
        setItemToDelete(null);
        setDataToImport(null);
    };

    // Price handler
    const handlePriceChange = async (name: string, unit: string, price: number) => {
        const key = `${name}-${unit}`;
        const newPrice = isNaN(price) || price < 0 ? 0 : price;

        setMaterialPrices(prev => ({
            ...prev,
            [key]: newPrice,
        }));
        
        await setMaterialPrice({ name, unit, price: newPrice });
        // After price change, update cost for current project if one is selected
        if (selectedProject?.id) {
            await updateCostForProject(selectedProject.id);
        }
    };
    
    // Exchange Rate Handler
    const handleExchangeRateChange = (rateStr: string) => {
        const newRate = parseFloat(rateStr);
        const rate = isNaN(newRate) || newRate <= 0 ? 1 : newRate;
        setExchangeRate(rate);
        localStorage.setItem('exchangeRateCUPtoUSD', rate.toString());
    };

    const formatCurrency = React.useCallback((value: number) => {
        const finalValue = displayCurrency === 'USD' ? value / exchangeRate : value;
        return `$${finalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }, [displayCurrency, exchangeRate]);

    // Calculations
    const totalMaterials = React.useMemo(() => {
        const summary: Record<string, Material> = {};
        activities.forEach(activity => {
            activity.results.forEach(material => {
                const key = `${material.name}-${material.unit}`;
                if (summary[key]) {
                    summary[key].quantity += material.quantity;
                } else {
                    summary[key] = { ...material };
                }
            });
        });
         return Object.values(summary)
            .map(material => ({
                ...material,
                unitPrice: materialPrices[`${material.name}-${material.unit}`] || 0,
            }))
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [activities, materialPrices]);

    const materialGrandTotal = React.useMemo(() => {
        return totalMaterials.reduce((total, material) => {
            return total + (material.quantity * (material.unitPrice || 0));
        }, 0);
    }, [totalMaterials]);

    const laborGrandTotal = React.useMemo(() => {
        return laborItems.reduce((total, item) => {
            return total + (item.quantity * item.unitPrice);
        }, 0);
    }, [laborItems]);

    const budgetGrandTotal = React.useMemo(() => {
        return budgetItems.reduce((total, item) => {
            return total + item.cost;
        }, 0);
    }, [budgetItems]);
    
    const financialSummary = React.useMemo(() => {
        const totalIncome = transactions
            .filter(t => t.type === TransactionType.INCOME)
            .reduce((sum, t) => sum + t.amount, 0);

        const totalExpense = transactions
            .filter(t => t.type === TransactionType.EXPENSE)
            .reduce((sum, t) => sum + t.amount, 0);
        
        const totalBudget = materialGrandTotal + laborGrandTotal + budgetGrandTotal;
        const balance = totalIncome - totalExpense;

        return { totalIncome, totalExpense, totalBudget, balance };
    }, [transactions, materialGrandTotal, laborGrandTotal, budgetGrandTotal]);
    
    const realCostsByCategory = React.useMemo(() => {
        const costs = {
            materials: 0,
            labor: 0,
            other: 0,
        };
        transactions
            .filter(t => t.type === TransactionType.EXPENSE)
            .forEach(t => {
                if (t.category === 'Materiales') {
                    costs.materials += t.amount;
                } else if (t.category === 'Mano de Obra') {
                    costs.labor += t.amount;
                } else {
                    costs.other += t.amount;
                }
            });
        return costs;
    }, [transactions]);


    const handleExportPDF = () => {
        if (selectedProject) {
            exportProjectToPDF(selectedProject, activities, totalMaterials, materialGrandTotal, laborItems, laborGrandTotal, budgetItems, budgetGrandTotal, transactions, exchangeRate);
        }
    };
    
    // Data Sync Handlers
    const handleExportData = async () => {
        try {
            const data = await exportAllData();
            const jsonString = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const date = new Date().toISOString().slice(0, 10);
            a.download = `habitex_calcula_backup_${date}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Error exporting data:", error);
            alert("Ocurrió un error al exportar los datos.");
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result;
                const data = JSON.parse(text as string);
                // Basic validation: Check for projects and the new dataLibrary
                if (data.projects && data.dataLibrary) {
                    setDataToImport(data);
                    setIsImportConfirmModalOpen(true);
                } else {
                    alert("El archivo de respaldo no tiene el formato correcto o está obsoleto.");
                }
            } catch (error) {
                console.error("Error parsing import file:", error);
                alert("Error al leer el archivo. Asegúrese de que sea un respaldo válido.");
            }
        };
        reader.readAsText(file);
        // Reset file input to allow re-uploading the same file
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleConfirmImport = async () => {
        if (!dataToImport) return;
        try {
            await importAllData(dataToImport);
            await loadInitialData(); // Refresh all data
            setSelectedProject(null); // Go back to project list
            closeModals();
            alert("¡Datos importados con éxito! Los proyectos existentes no han sido modificados.");
        } catch (error) {
            console.error("Error importing data:", error);
            alert("Ocurrió un error al importar los datos.");
        }
    };

    const handleDataLibrarySave = async (
        updatedLibrary: Record<string, any>, 
        originalLibrary: Record<string, any>,
        action: 'global' | 'global_and_recalculate' | 'project_only_update'
    ) => {
        setIsDataLibraryOpen(false); // Close modal immediately for better UX
        // TODO: Show a loading indicator/toast
        try {
            if (action === 'project_only_update' && selectedProject?.id) {
                const originalLabor = originalLibrary.labor_activities as PredefinedLaborActivity[];
                const updatedLabor = updatedLibrary.labor_activities as PredefinedLaborActivity[];
                
                const originalPriceMap = new Map(originalLabor.map(item => [item.name, item.priceMN]));
                const priceChanges = new Map<string, number>();

                for (const updatedItem of updatedLabor) {
                    const originalPrice = originalPriceMap.get(updatedItem.name);
                    if (originalPrice !== undefined && originalPrice !== updatedItem.priceMN) {
                        priceChanges.set(updatedItem.name, updatedItem.priceMN);
                    }
                }
                
                if (priceChanges.size > 0) {
                    const projectLaborItems = await getLaborItems(selectedProject.id);
                    const updatesToPerform = projectLaborItems
                        .filter(item => priceChanges.has(item.name) && item.unitPrice !== priceChanges.get(item.name))
                        .map(item => updateLaborItem({ ...item, unitPrice: priceChanges.get(item.name)! }));

                    await Promise.all(updatesToPerform);
                }
            } else {
                 // For global actions, save all changes to the database
                for (const key in updatedLibrary) {
                    if (updatedLibrary.hasOwnProperty(key)) {
                        await updateDataLibraryItem(key, updatedLibrary[key]);
                    }
                }

                // Optionally, trigger recalculation
                if (action === 'global_and_recalculate' && selectedProject?.id) {
                    const projectIdToRecalculate = selectedProject.id;
                    const [activitiesToUpdate, laborToUpdate, freshLibrary] = await Promise.all([
                        getActivities(projectIdToRecalculate),
                        getLaborItems(projectIdToRecalculate),
                        getDataLibrary(),
                    ]);

                    // Recalculate material activities
                    for (const activity of activitiesToUpdate) {
                        if (activity.type === ActivityType.CUSTOM) continue;
                        const newResults = await calculateMaterials(activity.type, activity.inputs);
                        await updateActivity({ ...activity, results: newResults });
                    }

                    // Update labor items
                    const laborLibrary: PredefinedLaborActivity[] = freshLibrary.labor_activities || [];
                    const laborPriceMap = new Map(laborLibrary.map(item => [item.name, item.priceMN]));
                    for (const laborItem of laborToUpdate) {
                        if (laborPriceMap.has(laborItem.name)) {
                            const newPrice = laborPriceMap.get(laborItem.name)!;
                            if (laborItem.unitPrice !== newPrice) {
                                await updateLaborItem({ ...laborItem, unitPrice: newPrice });
                            }
                        }
                    }
                }
            }
        } catch(e) {
            console.error("Error saving library or recalculating:", e);
            // TODO: Show an error toast
        } finally {
             // Refresh data everywhere
            await loadInitialData();
            if (selectedProject) {
                await loadProjectData();
            }
            // TODO: Hide loading indicator
        }
    };

    const renderProjectList = () => (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-slate-700">Mis Proyectos</h2>
                <div className="flex flex-wrap items-center gap-2">
                    <button
                        onClick={() => setIsDataLibraryOpen(true)}
                        className="flex items-center gap-2 px-3 py-2 bg-slate-100 text-slate-600 rounded-md hover:bg-slate-200 transition-colors shadow text-sm"
                        title="Biblioteca de Datos"
                    >
                        <CogIcon className="h-5 w-5" />
                        <span>Biblioteca</span>
                    </button>
                    <button
                        onClick={handleExportData}
                        className="flex items-center gap-2 px-3 py-2 bg-slate-500 text-white rounded-md hover:bg-slate-600 transition-colors shadow text-sm"
                        title="Exportar todos los datos a un archivo"
                    >
                        <ArrowUpTrayIcon className="h-5 w-5" />
                        Exportar
                    </button>
                    <label 
                        className="flex items-center gap-2 px-3 py-2 bg-slate-500 text-white rounded-md hover:bg-slate-600 transition-colors shadow cursor-pointer text-sm"
                        title="Importar datos desde un archivo (reemplazará los datos actuales)"
                    >
                        <ArrowDownTrayIcon className="h-5 w-5" />
                        Importar
                        <input
                            ref={fileInputRef}
                            type="file"
                            className="hidden"
                            accept=".json"
                            onChange={handleFileChange}
                        />
                    </label>
                    <button
                        onClick={() => handleOpenProjectModal(null)}
                        className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors shadow"
                    >
                        <PlusIcon className="h-5 w-5" />
                        Nuevo Proyecto
                    </button>
                </div>
            </div>
            {isLoading && projects.length === 0 && <p>Cargando proyectos...</p>}
            {!isLoading && projects.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-lg">
                    <p className="text-slate-500">No tienes proyectos aún.</p>
                    <p className="text-slate-400 text-sm">Crea tu primer proyecto para empezar a calcular materiales.</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {projects.map(project => (
                        <div key={project.id} className="p-4 border border-slate-200 rounded-lg flex justify-between items-center hover:shadow-md hover:border-cyan-200 transition-all">
                            <div>
                                <h3 className="text-lg font-semibold text-cyan-700 cursor-pointer" onClick={() => handleSelectProject(project)}>{project.name}</h3>
                                <p className="text-sm text-slate-500">Creado: {new Date(project.createdAt).toLocaleDateString()}</p>
                                {project.id && projectCosts[project.id] !== undefined && (
                                    <p className="text-sm text-slate-700 font-semibold mt-1">
                                        Costo Planificado: ${projectCosts[project.id].toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} CUP
                                    </p>
                                )}
                            </div>
                            <div className="flex items-center gap-2">
                                <button onClick={() => handleOpenProjectModal(project)} className="p-2 text-slate-500 hover:text-cyan-600"><PencilIcon className="h-5 w-5"/></button>
                                <button onClick={() => handleOpenDeleteModal('project', project.id!)} className="p-2 text-slate-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
    
    const renderActivityResults = (activity: Activity) => {
        const hasLayers = activity.type === ActivityType.REVESTIMIENTO && activity.results.some(r => r.layer);
    
        if (!hasLayers) {
            return (
                <ul className="mt-2 text-sm list-disc list-inside bg-slate-50 p-3 rounded">
                    {activity.results.map(res => (
                        <li key={`${res.name}-${res.unit}`}><strong>{res.name}:</strong> {res.quantity.toLocaleString()} {res.unit}</li>
                    ))}
                </ul>
            );
        }
    
        // Group materials by layer
        const groupedByLayer = activity.results.reduce((acc, material) => {
            const layer = material.layer || 'General';
            if (!acc[layer]) {
                acc[layer] = [];
            }
            acc[layer].push(material);
            return acc;
        }, {} as Record<string, Material[]>);
    
        return (
            <div className="mt-2 text-sm bg-slate-50 p-3 rounded space-y-3">
                {Object.entries(groupedByLayer).map(([layerName, materials]) => (
                    <div key={layerName}>
                        <h5 className="font-semibold text-slate-700">{layerName}</h5>
                        <ul className="list-disc list-inside pl-2">
                            {materials.map(res => (
                                <li key={`${layerName}-${res.name}-${res.unit}`}><strong>{res.name}:</strong> {res.quantity.toLocaleString()} {res.unit}</li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        );
    };

    const renderProjectDetailView = () => (
        <div className="bg-white p-6 rounded-lg shadow-lg">
            <div className="flex flex-wrap items-center gap-4 mb-4">
                <button onClick={() => setSelectedProject(null)} className="p-2 text-slate-500 hover:text-cyan-600 rounded-full bg-slate-100 hover:bg-slate-200">
                    <ArrowLeftIcon className="h-6 w-6"/>
                </button>
                <h2 className="text-2xl font-bold text-slate-700">{selectedProject?.name}</h2>
                <div className="ml-auto flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2">
                        <label htmlFor="exchangeRate" className="text-sm font-medium text-slate-600 whitespace-nowrap">Tasa (1 USD):</label>
                        <input
                            id="exchangeRate"
                            type="number"
                            value={exchangeRate}
                            onChange={(e) => handleExchangeRateChange(e.target.value)}
                            className="w-24 px-2 py-1 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-cyan-500 text-right"
                            placeholder="380"
                            step="1"
                            min="0.01"
                        />
                         <div className="flex rounded-md shadow-sm">
                            <button
                                type="button"
                                onClick={() => setDisplayCurrency('CUP')}
                                className={`px-3 py-1 text-sm font-medium ${displayCurrency === 'CUP' ? 'bg-cyan-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'} border border-slate-300 rounded-l-md focus:z-10 focus:ring-2 focus:ring-cyan-500`}
                            >
                                CUP
                            </button>
                            <button
                                type="button"
                                onClick={() => setDisplayCurrency('USD')}
                                className={`px-3 py-1 text-sm font-medium ${displayCurrency === 'USD' ? 'bg-cyan-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'} border-t border-b border-r border-slate-300 rounded-r-md focus:z-10 focus:ring-2 focus:ring-cyan-500`}
                            >
                                USD
                            </button>
                        </div>
                    </div>
                    <button
                        onClick={handleExportPDF}
                        className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors shadow"
                    >
                        <PdfIcon className="h-5 w-5" />
                        Exportar PDF
                    </button>
                </div>
            </div>
            
            {/* Tabs */}
            <div className="border-b border-slate-200 mb-6">
                <nav className="-mb-px flex gap-x-6 overflow-x-auto" aria-label="Tabs">
                    <button
                        onClick={() => setCurrentView('financials')}
                        className={`${
                            currentView === 'financials'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-4 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Control Financiero
                    </button>
                    <button
                        onClick={() => setCurrentView('materials')}
                        className={`${
                            currentView === 'materials'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-4 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Cálculo de Materiales
                    </button>
                    <button
                        onClick={() => setCurrentView('labor')}
                        className={`${
                            currentView === 'labor'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-4 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Mano de Obra
                    </button>
                    <button
                        onClick={() => setCurrentView('budget')}
                        className={`${
                            currentView === 'budget'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-4 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Otros Gastos (Plan)
                    </button>
                </nav>
            </div>

            {/* Content */}
            {currentView === 'financials' && renderFinancialsView()}
            {currentView === 'materials' && renderMaterialsView()}
            {currentView === 'labor' && renderLaborBudgetView()}
            {currentView === 'budget' && renderBudgetView()}
        </div>
    );

    const renderFinancialsView = () => {
        const { totalBudget, totalIncome, totalExpense, balance } = financialSummary;
        
        const StatCard = ({ icon, title, value, colorClass }: { icon: React.ReactNode, title: string, value: number, colorClass: string }) => (
            <div className="bg-white p-4 rounded-lg shadow flex items-center gap-4">
                <div className={`rounded-full p-3 ${colorClass}`}>
                    {icon}
                </div>
                <div>
                    <p className="text-sm text-slate-500">{title}</p>
                    <p className="text-xl font-bold text-slate-800">
                        {formatCurrency(value)}
                    </p>
                </div>
            </div>
        );

        const plannedCostsChart = {
            materials: materialGrandTotal,
            labor: laborGrandTotal,
            other: budgetGrandTotal,
        };

        return (
            <div>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <StatCard icon={<BanknotesIcon className="h-6 w-6 text-white"/>} title={`Presupuesto (${displayCurrency})`} value={totalBudget} colorClass="bg-blue-500" />
                    <StatCard icon={<ArrowTrendingDownIcon className="h-6 w-6 text-white"/>} title={`Total Ingresado (${displayCurrency})`} value={totalIncome} colorClass="bg-green-500" />
                    <StatCard icon={<ArrowTrendingUpIcon className="h-6 w-6 text-white"/>} title={`Total Gastado (${displayCurrency})`} value={totalExpense} colorClass="bg-red-500" />
                    <StatCard icon={<ScaleIcon className="h-6 w-6 text-white"/>} title={`Balance Actual (${displayCurrency})`} value={balance} colorClass="bg-yellow-500" />
                </div>

                 <div className="bg-white p-4 rounded-lg shadow mb-6">
                    <h3 className="text-lg font-semibold text-slate-700 mb-4">Comparación: Planificado vs. Real ({displayCurrency})</h3>
                    <FinancialChart 
                        plannedCosts={plannedCostsChart}
                        realCosts={realCostsByCategory}
                        currency={displayCurrency}
                        exchangeRate={exchangeRate}
                    />
                </div>

                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-slate-600">Historial de Transacciones</h3>
                    <div className="flex gap-2">
                        <button 
                            onClick={() => { setEditingTransaction(null); setIsTransactionModalOpen(true); }}
                            className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors shadow"
                        >
                            <PlusIcon className="h-5 w-5" />
                            Añadir Transacción
                        </button>
                    </div>
                </div>

                {isLoading ? <p>Cargando...</p> : transactions.length === 0 ? (
                    <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-lg">
                        <p className="text-slate-500">No hay transacciones registradas.</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                         <table className="w-full text-sm text-left text-slate-700">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-100">
                                <tr>
                                    <th className="px-4 py-3">Fecha</th>
                                    <th className="px-4 py-3">Descripción</th>
                                    <th className="px-4 py-3">Categoría</th>
                                    <th className="px-4 py-3 text-right">Monto ({displayCurrency})</th>
                                    <th className="px-4 py-3 text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {transactions.map(item => (
                                    <tr key={item.id} className="border-b hover:bg-slate-50">
                                        <td className="px-4 py-2">{new Date(item.date).toLocaleDateString()}</td>
                                        <td className="px-4 py-2 font-medium">{item.description}</td>
                                        <td className="px-4 py-2"><span className="text-xs bg-slate-200 px-2 py-1 rounded-full">{item.category || 'N/A'}</span></td>
                                        <td className={`px-4 py-2 text-right font-semibold ${item.type === TransactionType.INCOME ? 'text-green-600' : 'text-red-600'}`}>
                                            {item.type === TransactionType.INCOME ? '+' : '-'} {formatCurrency(item.amount)}
                                        </td>
                                        <td className="px-4 py-2 text-center">
                                            <div className="flex items-center justify-center gap-2">
                                                <button onClick={() => { setEditingTransaction(item); setIsTransactionModalOpen(true); }} className="p-2 text-slate-500 hover:text-cyan-600"><PencilIcon className="h-5 w-5"/></button>
                                                <button onClick={() => handleOpenDeleteModal('transaction', item.id!)} className="p-2 text-slate-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                         </table>
                    </div>
                )}
            </div>
        );
    };

    const renderMaterialsView = () => (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
                <h3 className="text-xl font-semibold mb-4 text-slate-600">Actividades de Materiales</h3>
                <div className="space-y-4">
                     <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                        {Object.values(ActivityType).filter(type => type !== ActivityType.CUSTOM).map(type => (
                            <button
                                key={type}
                                onClick={() => handleOpenActivityModal(type, null)}
                                className="p-3 bg-slate-100 text-slate-700 rounded-md hover:bg-cyan-100 hover:text-cyan-800 transition-colors text-center text-sm font-medium"
                            >
                                {type}
                            </button>
                        ))}
                         <button
                            onClick={() => handleOpenActivityModal(ActivityType.CUSTOM, null)}
                            className="p-3 bg-cyan-100 text-cyan-800 rounded-md hover:bg-cyan-200 transition-colors text-center text-sm font-medium col-span-2 md:col-span-3 lg:col-span-4"
                        >
                            {ActivityType.CUSTOM}
                        </button>
                    </div>
                    {isLoading && <p>Cargando actividades...</p>}
                    {!isLoading && activities.length === 0 ? (
                         <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-lg">
                            <p className="text-slate-500">No hay actividades de materiales.</p>
                        </div>
                    ) : (
                        activities.map(activity => (
                            <div key={activity.id} className="p-4 border rounded-lg">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h4 className="font-bold text-slate-800">{activity.name}</h4>
                                        <p className="text-sm text-cyan-600 font-medium">{getActivitySubtitle(activity)}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button onClick={() => handleOpenActivityModal(activity.type, activity)} className="p-2 text-slate-500 hover:text-cyan-600"><PencilIcon className="h-5 w-5"/></button>
                                        <button onClick={() => handleOpenDeleteModal('activity', activity.id!)} className="p-2 text-slate-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                                    </div>
                                </div>
                                <details className="mt-3">
                                    <summary className="cursor-pointer text-sm text-slate-600 flex items-center">
                                        Ver Materiales <ChevronDownIcon className="h-4 w-4 ml-1"/>
                                    </summary>
                                    {renderActivityResults(activity)}
                                </details>
                            </div>
                        ))
                    )}
                </div>
            </div>
            <div>
                <h3 className="text-xl font-semibold mb-4 text-slate-600">Resumen de Materiales</h3>
                 <div className="bg-slate-50 p-4 rounded-lg max-h-[32rem] overflow-y-auto">
                    {totalMaterials.length === 0 ? (
                        <p className="text-slate-500 text-sm">No hay materiales para mostrar.</p>
                    ) : (
                        <table className="w-full text-sm text-left text-slate-700">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-100 sticky top-0">
                                <tr>
                                    <th scope="col" className="px-4 py-3">Material</th>
                                    <th scope="col" className="px-4 py-3 text-right">Cantidad</th>
                                    <th scope="col" className="px-4 py-3">Precio Unit. (CUP)</th>
                                    <th scope="col" className="px-4 py-3 text-right">Precio Total ({displayCurrency})</th>
                                </tr>
                            </thead>
                            <tbody>
                                {totalMaterials.map(material => {
                                    const key = `${material.name}-${material.unit}`;
                                    const totalPrice = material.quantity * (material.unitPrice || 0);
                                    return (
                                        <tr key={key} className="border-b border-slate-200 hover:bg-slate-100">
                                            <th scope="row" className="px-4 py-2 font-medium text-slate-800 whitespace-nowrap">
                                                {material.name}
                                            </th>
                                            <td className="px-4 py-2 text-right">
                                                {material.quantity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {material.unit}
                                            </td>
                                            <td className="px-4 py-2 w-32">
                                                <input 
                                                    type="number"
                                                    value={material.unitPrice || ''}
                                                    onChange={(e) => handlePriceChange(material.name, material.unit, parseFloat(e.target.value))}
                                                    className="w-full px-2 py-1 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-cyan-500 text-right"
                                                    placeholder="0.00"
                                                    step="0.01"
                                                    min="0"
                                                />
                                            </td>
                                            <td className="px-4 py-2 text-right font-semibold text-slate-800">
                                                {formatCurrency(totalPrice)}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                            <tfoot>
                                <tr className="font-bold text-slate-900 bg-slate-100">
                                    <td colSpan={3} className="px-4 py-2 text-right text-base">TOTAL ({displayCurrency})</td>
                                    <td className="px-4 py-2 text-right text-base">
                                        {formatCurrency(materialGrandTotal)}
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );

    const renderLaborBudgetView = () => (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-slate-600">Actividades de Mano de Obra</h3>
                <button 
                    onClick={() => { setEditingLaborItem(null); setIsLaborItemModalOpen(true); }}
                    className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors shadow"
                >
                    <PlusIcon className="h-5 w-5" />
                    Añadir Actividad
                </button>
            </div>
             {isLoading ? <p>Cargando...</p> : laborItems.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-lg">
                    <p className="text-slate-500">No hay actividades de mano de obra.</p>
                </div>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-700">
                        <thead className="text-xs text-slate-500 uppercase bg-slate-100">
                            <tr>
                                <th className="px-4 py-3">Actividad</th>
                                <th className="px-4 py-3">Unidad</th>
                                <th className="px-4 py-3">Cantidad</th>
                                <th className="px-4 py-3">Precio Unit. (CUP)</th>
                                <th className="px-4 py-3 text-right">Subtotal ({displayCurrency})</th>
                                <th className="px-4 py-3 text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {laborItems.map(item => (
                                <tr key={item.id} className="border-b hover:bg-slate-50">
                                    <td className="px-4 py-2 font-medium">{item.name}</td>
                                    <td className="px-4 py-2">{item.unit}</td>
                                    <td className="px-4 py-2">{item.quantity.toLocaleString()}</td>
                                    <td className="px-4 py-2">{item.unitPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                                    <td className="px-4 py-2 text-right font-semibold">{formatCurrency(item.quantity * item.unitPrice)}</td>
                                    <td className="px-4 py-2 text-center">
                                         <div className="flex items-center justify-center gap-2">
                                            <button onClick={() => { setEditingLaborItem(item); setIsLaborItemModalOpen(true); }} className="p-2 text-slate-500 hover:text-cyan-600"><PencilIcon className="h-5 w-5"/></button>
                                            <button onClick={() => handleOpenDeleteModal('labor', item.id!)} className="p-2 text-slate-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot>
                             <tr className="font-bold text-slate-900 bg-slate-100">
                                <td colSpan={4} className="px-4 py-2 text-right text-base">TOTAL ({displayCurrency})</td>
                                <td className="px-4 py-2 text-right text-base">
                                    {formatCurrency(laborGrandTotal)}
                                </td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            )}
        </div>
    );

    const renderBudgetView = () => (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-slate-600">Otros Gastos Planificados</h3>
                <button 
                    onClick={() => { setEditingBudgetItem(null); setIsBudgetItemModalOpen(true); }}
                    className="flex items-center gap-2 px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors shadow"
                >
                    <PlusIcon className="h-5 w-5" />
                    Añadir Gasto
                </button>
            </div>
             {isLoading ? <p>Cargando...</p> : budgetItems.length === 0 ? (
                <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-lg">
                    <p className="text-slate-500">No hay otros gastos planificados.</p>
                </div>
            ) : (
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-700">
                        <thead className="text-xs text-slate-500 uppercase bg-slate-100">
                            <tr>
                                <th className="px-4 py-3">Categoría</th>
                                <th className="px-4 py-3">Descripción</th>
                                <th className="px-4 py-3 text-right">Costo ({displayCurrency})</th>
                                <th className="px-4 py-3 text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {budgetItems.map(item => (
                                <tr key={item.id} className="border-b hover:bg-slate-50">
                                    <td className="px-4 py-2 font-medium">{item.category}</td>
                                    <td className="px-4 py-2">{item.name}</td>
                                    <td className="px-4 py-2 text-right font-semibold">{formatCurrency(item.cost)}</td>
                                    <td className="px-4 py-2 text-center">
                                         <div className="flex items-center justify-center gap-2">
                                            <button onClick={() => { setEditingBudgetItem(item); setIsBudgetItemModalOpen(true); }} className="p-2 text-slate-500 hover:text-cyan-600"><PencilIcon className="h-5 w-5"/></button>
                                            <button onClick={() => handleOpenDeleteModal('budget', item.id!)} className="p-2 text-slate-500 hover:text-red-600"><TrashIcon className="h-5 w-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot>
                             <tr className="font-bold text-slate-900 bg-slate-100">
                                <td colSpan={2} className="px-4 py-2 text-right text-base">TOTAL ({displayCurrency})</td>
                                <td className="px-4 py-2 text-right text-base">
                                    {formatCurrency(budgetGrandTotal)}
                                </td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            )}
        </div>
    );
    
    // RENDER MAIN COMPONENT
    return (
        <div>
            {selectedProject ? renderProjectDetailView() : renderProjectList()}
            
            <Modal isOpen={isProjectModalOpen} onClose={closeModals} title={editingProject ? "Editar Proyecto" : "Nuevo Proyecto"}>
                <div className="space-y-4">
                    <label htmlFor="projectName" className="block text-sm font-medium text-slate-700">Nombre del Proyecto</label>
                    <input
                        id="projectName"
                        type="text"
                        value={newProjectName}
                        onChange={(e) => setNewProjectName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                        placeholder="Ej: Remodelación Casa"
                    />
                </div>
                <div className="flex justify-end gap-4 mt-6">
                     <button type="button" onClick={closeModals} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                     <button onClick={handleSaveProject} className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 shadow">Guardar</button>
                </div>
            </Modal>

            <Modal isOpen={isActivityModalOpen} onClose={closeModals} title={editingActivity ? `Editar: ${editingActivity.name}` : `Nueva Actividad: ${selectedActivityType}`}>
                {selectedActivityType && (
                    <ActivityForm
                        activityType={selectedActivityType}
                        onSave={handleSaveActivity}
                        onCancel={closeModals}
                        initialData={
                            editingActivity && editingActivity.type === ActivityType.CUSTOM
                                ? { ...editingActivity.inputs, customName: editingActivity.name }
                                : editingActivity?.inputs || {}
                        }
                    />
                )}
            </Modal>
            
            {isLaborItemModalOpen && 
                <AddLaborItemModal 
                    isOpen={isLaborItemModalOpen}
                    onClose={closeModals}
                    onSave={handleSaveLaborItem}
                    onSaveAndAddMaterials={handleSaveLaborAndAddMaterials}
                    initialData={editingLaborItem}
                />
            }
            
            {isBudgetItemModalOpen &&
                <BudgetItemModal
                    isOpen={isBudgetItemModalOpen}
                    onClose={closeModals}
                    onSave={handleSaveBudgetItem}
                    initialData={editingBudgetItem}
                />
            }
            
            {isTransactionModalOpen &&
                <TransactionModal
                    isOpen={isTransactionModalOpen}
                    onClose={closeModals}
                    onSave={handleSaveTransaction}
                    initialData={editingTransaction}
                />
            }

            <Modal isOpen={isDataLibraryOpen} onClose={closeModals} title="Biblioteca de Datos">
                <DataLibrary 
                    selectedProject={selectedProject}
                    onSaveChanges={handleDataLibrarySave}
                    onClose={closeModals}
                />
            </Modal>

            <Modal isOpen={isDeleteModalOpen} onClose={closeModals} title="Confirmar Eliminación">
                <p>¿Estás seguro de que deseas eliminar este {itemToDelete?.type === 'project' ? 'proyecto y todos sus datos' : 'elemento'}? Esta acción no se puede deshacer.</p>
                <div className="flex justify-end gap-4 mt-6">
                    <button type="button" onClick={closeModals} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                    <button onClick={handleConfirmDelete} className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 shadow">Eliminar</button>
                </div>
            </Modal>

            <Modal isOpen={isImportConfirmModalOpen} onClose={closeModals} title="Confirmar Importación">
                <div className="text-center">
                    <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-cyan-100">
                        <svg className="h-6 w-6 text-cyan-600" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
                        </svg>
                    </div>
                    <h3 className="mt-2 text-lg font-medium text-slate-900">Importar y Reemplazar Datos</h3>
                    <div className="mt-2 text-sm text-slate-500">
                        <p className="font-bold text-red-600">¡Atención! Esta acción reemplazará todos los datos existentes, incluyendo proyectos y la biblioteca de datos, con la información del archivo.</p>
                        <p className="mt-2">Se recomienda exportar los datos actuales como respaldo antes de continuar.</p>
                    </div>
                </div>
                <div className="flex justify-center gap-4 mt-6">
                    <button type="button" onClick={closeModals} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                    <button onClick={handleConfirmImport} className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 shadow">Sí, importar y reemplazar</button>
                </div>
            </Modal>
        </div>
    );
};

export default ProjectManager;