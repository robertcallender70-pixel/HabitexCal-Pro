import React from 'react';
import Modal from './Modal';
import type { Transaction } from '../types';
import { TransactionType } from '../types';

const Input = (props: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) => (
    <div>
        <label className="block text-sm font-medium text-slate-600 mb-1">{props.label}</label>
        <input {...props} className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition" />
    </div>
);

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement> & { label: string, children: React.ReactNode }) => (
     <div>
        <label className="block text-sm font-medium text-slate-600 mb-1">{props.label}</label>
        <select {...props} className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition bg-white">
            {props.children}
        </select>
    </div>
);

export const TransactionModal = ({ isOpen, onClose, onSave, initialData }: {isOpen: boolean, onClose: () => void, onSave: (item: any) => void, initialData: Transaction | null}) => {
    const [type, setType] = React.useState<TransactionType>(initialData?.type || TransactionType.EXPENSE);
    const [description, setDescription] = React.useState(initialData?.description || '');
    const [amount, setAmount] = React.useState<string>(initialData?.amount?.toString() || '');
    const [date, setDate] = React.useState(initialData?.date || new Date().toISOString().slice(0, 10));
    const [category, setCategory] = React.useState(initialData?.category || 'Materiales');
    
    const EXPENSE_CATEGORIES = ['Materiales', 'Mano de Obra', 'Transporte', 'Herramientas', 'Permisos', 'Otros'];

    const handleSave = () => {
        const numAmount = parseFloat(amount);
        if (description && numAmount > 0 && date) {
            const transactionData: Omit<Transaction, 'id' | 'projectId'> = {
                type,
                description,
                amount: numAmount,
                date,
                category: type === TransactionType.EXPENSE ? category : undefined,
            };
            onSave(transactionData);
        } else {
             alert("Por favor, complete todos los campos con valores válidos.");
        }
    }

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={initialData ? "Editar Transacción" : "Nueva Transacción"}>
            <div className="space-y-4">
                 <div className="flex rounded-md shadow-sm">
                    <button
                        type="button"
                        onClick={() => setType(TransactionType.EXPENSE)}
                        className={`px-4 py-2 text-sm font-medium ${type === TransactionType.EXPENSE ? 'bg-cyan-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'} border border-slate-300 rounded-l-md focus:z-10 focus:ring-2 focus:ring-cyan-500`}
                    >
                        Gasto
                    </button>
                    <button
                        type="button"
                        onClick={() => setType(TransactionType.INCOME)}
                        className={`px-4 py-2 text-sm font-medium ${type === TransactionType.INCOME ? 'bg-cyan-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-50'} border-t border-b border-r border-slate-300 rounded-r-md focus:z-10 focus:ring-2 focus:ring-cyan-500`}
                    >
                        Ingreso
                    </button>
                </div>
                
                <Input label="Descripción" type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder={type === TransactionType.EXPENSE ? "Ej: Compra de cemento" : "Ej: Anticipo del cliente"} />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input label="Monto (CUP)" type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" step="0.01" />
                    <Input label="Fecha" type="date" value={date} onChange={e => setDate(e.target.value)} />
                </div>
                
                {type === TransactionType.EXPENSE && (
                    <Select label="Categoría del Gasto" value={category} onChange={e => setCategory(e.target.value)}>
                        {EXPENSE_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                    </Select>
                )}
            </div>
             <div className="flex justify-end gap-4 mt-6 pt-4 border-t">
                <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                <button onClick={handleSave} className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 shadow">Guardar</button>
            </div>
        </Modal>
    )
}

export default TransactionModal;
