import React from 'react';
import { getDataLibrary } from '../services/database';
import type { PredefinedLaborActivity, Project } from '../types';
import Modal from './Modal';
import { PlusIcon, TrashIcon } from '../constants';

const Input = (props: React.InputHTMLAttributes<HTMLInputElement> & { label?: string, hideLabel?: boolean }) => (
    <div>
        {props.label && !props.hideLabel && <label className="block text-xs font-medium text-slate-600 mb-1">{props.label}</label>}
        <input {...props} className="w-full px-2 py-1 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-cyan-500 text-slate-900" />
    </div>
);

const Select = (props: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string }) => (
     <div>
        {props.label && <label className="block text-xs font-medium text-slate-600 mb-1">{props.label}</label>}
        <select {...props} className="w-full px-2 py-1 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-cyan-500 transition bg-white">
            {props.children}
        </select>
    </div>
);


// --- Labor Library Component ---
const DataLibraryLabor = ({ data, onUpdate }: { data: PredefinedLaborActivity[], onUpdate: (data: PredefinedLaborActivity[]) => void }) => {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [newActivity, setNewActivity] = React.useState({ name: '', unit: '', priceMN: '', category: 'construction' });
    
    const laborCategories = React.useMemo(() => {
        if (!data) return [];
        const categories = Array.from(new Set(data.map(a => a.category)));
        return categories.sort();
    }, [data]);
    
    const categoryDisplayNames: Record<string, string> = {
        excavation: 'Excavación',
        construction: 'Construcción',
        finishing: 'Acabado',
        demolition: 'Demolición',
        plumbing: 'Plomería',
        electrical: 'Electricidad'
    };

    const handlePriceChange = (id: number, newPrice: string) => {
        const updatedData = data.map(item =>
            item.id === id ? { ...item, priceMN: parseFloat(newPrice) || 0 } : item
        );
        onUpdate(updatedData);
    };

    const handleAddNewActivity = () => {
        const { name, unit, priceMN, category } = newActivity;
        if (!name || !unit || !priceMN) {
            alert("Por favor complete todos los campos para la nueva actividad.");
            return;
        }

        const newId = Math.max(0, ...data.map(d => d.id)) + 1;
        const activityToAdd: PredefinedLaborActivity = {
            id: newId,
            name,
            unit,
            priceMN: parseFloat(priceMN),
            category
        };
        onUpdate([...data, activityToAdd]);
        setNewActivity({ name: '', unit: '', priceMN: '', category: 'construction' }); // Reset form
    };

    const handleDeleteActivity = (id: number) => {
        if (window.confirm("¿Está seguro de que desea eliminar esta actividad de la biblioteca global?")) {
            onUpdate(data.filter(item => item.id !== id));
        }
    };

    const filteredData = (data || []).filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div className="space-y-4">
            <Input label="Buscar Actividad" type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Escriba para filtrar..." />
            <div className="max-h-[55vh] overflow-y-auto border rounded-lg">
                <table className="w-full text-sm text-left">
                    <thead className="text-xs text-slate-600 uppercase bg-slate-100 sticky top-0 z-10">
                        <tr>
                            <th className="px-4 py-2">Actividad</th>
                            <th className="px-4 py-2 w-24">Unidad</th>
                            <th className="px-4 py-2 w-40">Precio (CUP)</th>
                            <th className="px-4 py-2 w-16 text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y">
                        {filteredData.map(item => (
                            <tr key={item.id} className="hover:bg-slate-50">
                                <td className="px-4 py-2 font-medium text-slate-900">{item.name}</td>
                                <td className="px-4 py-2 text-slate-900">{item.unit}</td>
                                <td className="px-4 py-2">
                                    <Input
                                        type="number"
                                        hideLabel
                                        value={item.priceMN}
                                        onChange={e => handlePriceChange(item.id, e.target.value)}
                                        step="0.01"
                                    />
                                </td>
                                <td className="px-4 py-2 text-center">
                                    <button onClick={() => handleDeleteActivity(item.id)} className="p-1 text-slate-400 hover:text-red-600" title="Eliminar Actividad">
                                        <TrashIcon className="h-5 w-5" />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                    <tfoot className="bg-slate-50">
                        <tr>
                            <td className="px-4 py-2">
                                <Input hideLabel placeholder="Nombre nueva actividad" value={newActivity.name} onChange={e => setNewActivity(p => ({ ...p, name: e.target.value }))} />
                            </td>
                             <td className="px-4 py-2">
                                <Input hideLabel placeholder="Unidad" value={newActivity.unit} onChange={e => setNewActivity(p => ({ ...p, unit: e.target.value }))} />
                            </td>
                            <td className="px-4 py-2">
                                <Input hideLabel type="number" placeholder="Precio" value={newActivity.priceMN} onChange={e => setNewActivity(p => ({ ...p, priceMN: e.target.value }))} />
                            </td>
                            <td className="px-4 py-2 text-center">
                                <button onClick={handleAddNewActivity} className="p-1 text-slate-400 hover:text-green-600" title="Añadir Actividad">
                                    <PlusIcon className="h-6 w-6" />
                                </button>
                            </td>
                        </tr>
                        <tr>
                            <td colSpan={4} className="px-4 pb-2">
                                <Select value={newActivity.category} onChange={e => setNewActivity(p => ({...p, category: e.target.value}))}>
                                     {laborCategories.map(cat => <option key={cat} value={cat}>{categoryDisplayNames[cat] || cat}</option>)}
                                </Select>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};

// --- Formulas Library Component ---
const DataLibraryFormulas = ({ data, onUpdate }: { data: Record<string, any>, onUpdate: (libraryKey: string, sectionData: any) => void }) => {
    const handleUpdate = (libraryKey: string, updatedSectionData: any) => {
        onUpdate(libraryKey, updatedSectionData);
    };

    const FormulaSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
        <details className="p-4 border rounded-lg bg-white" open>
            <summary className="font-semibold text-lg cursor-pointer text-slate-700">{title}</summary>
            <div className="mt-4">{children}</div>
        </details>
    );
    
    const GenericTableEditor = ({ libraryKey, sectionData, columns, onUpdate }: { libraryKey: string, sectionData: any[], columns: { key: keyof any, label: string, type?: string, editable: boolean }[], onUpdate: Function }) => {
        const handleCellChange = (rowIndex: number, key: keyof any, value: any) => {
            const updatedData = [...sectionData];
            updatedData[rowIndex] = { ...updatedData[rowIndex], [key]: value };
            onUpdate(libraryKey, updatedData);
        };

        return (
             <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead className="text-xs text-slate-600 uppercase bg-slate-100">
                        <tr>
                            {columns.map(col => <th key={String(col.key)} className="px-4 py-2 text-left">{col.label}</th>)}
                        </tr>
                    </thead>
                    <tbody className="divide-y">
                        {(sectionData || []).map((row, rowIndex) => (
                            <tr key={rowIndex} className="hover:bg-slate-50">
                                {columns.map(col => (
                                    <td key={String(col.key)} className="px-4 py-2">
                                        {col.editable ? (
                                            <Input
                                                hideLabel
                                                type={col.type || 'number'}
                                                value={row[col.key]}
                                                onChange={e => handleCellChange(rowIndex, col.key, col.type === 'text' ? e.target.value : parseFloat(e.target.value) || 0)}
                                                step="0.001"
                                            />
                                        ) : (
                                            <span className="text-slate-900">{row[col.key]}</span>
                                        )}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    };
    
    const GenericObjectEditor = ({ libraryKey, data, onUpdate }: { libraryKey: string, data: Record<string, number>, onUpdate: Function }) => {
        const handleChange = (key: string, value: string) => {
            const updatedData = { ...data, [key]: parseFloat(value) || 0 };
            onUpdate(libraryKey, updatedData);
        };
        return (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Object.entries(data || {}).map(([key, value]) => (
                    <Input
                        key={key}
                        label={key.replace(/_/g, ' ')}
                        type="number"
                        value={value}
                        onChange={(e) => handleChange(key, e.target.value)}
                        step="0.001"
                    />
                ))}
            </div>
        )
    };
    
    return (
        <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2 bg-slate-50 p-2 rounded-lg">
            {data.hormigones && <FormulaSection title="Dosificación de Hormigones">
                <GenericTableEditor
                    libraryKey="hormigones"
                    sectionData={data.hormigones}
                    onUpdate={handleUpdate}
                    columns={[
                        { key: 'resistencia', label: 'Resistencia (Kg/cm²)', editable: false },
                        { key: 'cemento', label: 'Cemento (sacos)', editable: true },
                        { key: 'arena', label: 'Arena (m³)', editable: true },
                        { key: 'piedra', label: 'Piedra (m³)', editable: true },
                        { key: 'agua', label: 'Agua (L)', editable: true },
                    ]}
                />
            </FormulaSection>}
            {data.acero_barras && <FormulaSection title="Datos de Barras de Acero">
                <GenericTableEditor
                    libraryKey="acero_barras"
                    sectionData={data.acero_barras}
                    onUpdate={handleUpdate}
                    columns={[
                        { key: 'barra', label: '# Barra', editable: false },
                        { key: 'pulgadas', label: 'Pulgadas', editable: true, type: 'text' },
                        { key: 'pesoUnit', label: 'Peso (kg/m)', editable: true },
                    ]}
                />
            </FormulaSection>}
            {data.morteros_muros && <FormulaSection title="Morteros para Muros (por m²)">
                <GenericTableEditor
                    libraryKey="morteros_muros"
                    sectionData={data.morteros_muros}
                    onUpdate={handleUpdate}
                    columns={[
                        { key: 'nombre', label: 'Tipo', editable: false },
                        { key: 'unidades', label: 'Unidades', editable: true },
                        { key: 'cemento', label: 'Cemento (sacos)', editable: true },
                        { key: 'arena', label: 'Arena (m³)', editable: true },
                        { key: 'polvoPiedra', label: 'Polvo Piedra (m³)', editable: true },
                    ]}
                />
            </FormulaSection>}
            {data.morteros_revestimiento && <FormulaSection title="Morteros para Revestimiento (por m²)">
                 <GenericTableEditor
                    libraryKey="morteros_revestimiento"
                    sectionData={data.morteros_revestimiento}
                    onUpdate={handleUpdate}
                    columns={[
                        { key: 'nombre', label: 'Tipo', editable: false },
                        { key: 'cemento', label: 'Cemento (sacos)', editable: true },
                        { key: 'arena', label: 'Arena (m³)', editable: true },
                        { key: 'polvoPiedra', label: 'Polvo Piedra (m³)', editable: true },
                    ]}
                />
            </FormulaSection>}
            {data.morteros_piso && <FormulaSection title="Morteros para Pisos (por m² o m)">
                 <GenericTableEditor
                    libraryKey="morteros_piso"
                    sectionData={data.morteros_piso}
                    onUpdate={handleUpdate}
                    columns={[
                        { key: 'nombre', label: 'Tipo', editable: false },
                        { key: 'unidades', label: 'Unidades', editable: true },
                        { key: 'cemento', label: 'Cemento (sacos)', editable: true },
                        { key: 'arena', label: 'Arena (m³)', editable: true },
                        { key: 'polvoPiedra', label: 'Polvo Piedra (m³)', editable: true },
                    ]}
                />
            </FormulaSection>}
            {data.pintura && <FormulaSection title="Rendimiento de Pintura (litros/m²)">
                <GenericObjectEditor libraryKey="pintura" data={data.pintura} onUpdate={handleUpdate} />
            </FormulaSection>}
            {data.enchape && <FormulaSection title="Materiales de Enchape (por m²)">
                <GenericObjectEditor libraryKey="enchape" data={data.enchape} onUpdate={handleUpdate} />
            </FormulaSection>}
            {data.pladur_pared && <FormulaSection title="Estructura de Pladur - Pared (por m²)">
                <GenericObjectEditor libraryKey="pladur_pared" data={data.pladur_pared} onUpdate={handleUpdate} />
            </FormulaSection>}
            {data.pladur_techo && <FormulaSection title="Estructura de Pladur - Techo (por m²)">
                <GenericObjectEditor libraryKey="pladur_techo" data={data.pladur_techo} onUpdate={handleUpdate} />
            </FormulaSection>}
        </div>
    );
};

interface DataLibraryProps {
    selectedProject: Project | null;
    onSaveChanges: (updatedLibrary: Record<string, any>, originalLibrary: Record<string, any>, action: 'global' | 'global_and_recalculate' | 'project_only_update') => void;
    onClose: () => void;
}

const DataLibrary: React.FC<DataLibraryProps> = ({ selectedProject, onSaveChanges, onClose }) => {
    const [activeTab, setActiveTab] = React.useState<'labor' | 'formulas'>('labor');
    const [originalLibrary, setOriginalLibrary] = React.useState<Record<string, any> | null>(null);
    const [localLibrary, setLocalLibrary] = React.useState<Record<string, any> | null>(null);
    const [isLoading, setIsLoading] = React.useState(true);
    const [isDirty, setIsDirty] = React.useState(false);
    const [isPriceOnlyChange, setIsPriceOnlyChange] = React.useState(false);
    const [isConfirmSaveOpen, setIsConfirmSaveOpen] = React.useState(false);

    React.useEffect(() => {
        const loadLibrary = async () => {
            setIsLoading(true);
            try {
                const data = await getDataLibrary();
                if (!data) throw new Error("Library data is empty or failed to load.");
                setOriginalLibrary(JSON.parse(JSON.stringify(data))); // Deep copy for reset
                setLocalLibrary(data);
            } catch (error) {
                console.error("Failed to load data library:", error);
            } finally {
                setIsLoading(false);
            }
        };
        loadLibrary();
    }, []);
    
    React.useEffect(() => {
        if (!originalLibrary || !localLibrary) return;

        // FIX: Explicitly type `originalLabor` and `localLabor` as `PredefinedLaborActivity[]`.
        const originalLabor: PredefinedLaborActivity[] = originalLibrary.labor_activities || [];
        const localLabor: PredefinedLaborActivity[] = localLibrary.labor_activities || [];

        if (originalLabor.length !== localLabor.length) {
            setIsPriceOnlyChange(false);
            return;
        }

        // FIX: Explicitly type the Map to ensure `originalItem` is correctly typed.
        const originalMap = new Map<number, PredefinedLaborActivity>(originalLabor.map((item) => [item.id, item]));
        let priceOnly = true;
        for (const localItem of localLabor) {
            const originalItem = originalMap.get(localItem.id);
            if (!originalItem) {
                priceOnly = false;
                break;
            }
            // Check if any property other than priceMN has changed
            if (originalItem.name !== localItem.name || originalItem.unit !== localItem.unit || originalItem.category !== localItem.category) {
                priceOnly = false;
                break;
            }
        }
        setIsPriceOnlyChange(priceOnly);

    }, [localLibrary, originalLibrary]);

    const handleLocalUpdate = (key: string, data: any) => {
        setLocalLibrary(prev => ({
            ...prev,
            [key]: data
        }));
        setIsDirty(true);
    };

    const handleLaborUpdate = (data: any) => {
        handleLocalUpdate('labor_activities', data);
    }
    
    const handleAttemptSave = () => {
        if (isDirty) {
            setIsConfirmSaveOpen(true);
        } else {
            onClose(); // Nothing to save, just close
        }
    };

    if (isLoading) {
        return <p className="text-center p-8">Cargando biblioteca de datos...</p>;
    }
    
    if (!localLibrary || !originalLibrary) {
        return <p className="text-center p-8 text-red-500">No se pudo cargar la biblioteca de datos.</p>;
    }

    const renderSaveConfirmation = () => {
        if (!selectedProject) {
            return (
                <div>
                    <h3 className="text-lg font-medium text-slate-900">Guardar en Biblioteca Global</h3>
                    <p className="mt-2 text-sm text-slate-500">Los cambios se guardarán y se aplicarán a todos los cálculos nuevos en todos los proyectos. ¿Desea continuar?</p>
                    <div className="flex justify-end gap-4 mt-6">
                        <button onClick={() => setIsConfirmSaveOpen(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                        <button onClick={() => { onSaveChanges(localLibrary, originalLibrary, 'global'); setIsConfirmSaveOpen(false); }} className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 shadow">Guardar</button>
                    </div>
                </div>
            );
        }

        return (
            <div>
                 <h3 className="text-lg font-medium text-slate-900">Aplicar Cambios</h3>
                 <p className="mt-2 text-sm text-slate-500">Ha modificado valores de la biblioteca. ¿Cómo desea aplicar estos cambios?</p>
                 <div className="mt-4 space-y-4">
                    <button 
                        onClick={() => { onSaveChanges(localLibrary, originalLibrary, 'global_and_recalculate'); setIsConfirmSaveOpen(false); }}
                        className="w-full text-left p-3 border rounded-lg hover:bg-cyan-50 hover:border-cyan-400 transition-colors"
                    >
                        <p className="font-semibold text-cyan-700">Guardar Globalmente y Actualizar Proyecto</p>
                        <p className="text-xs text-slate-600">Guarda los cambios en la biblioteca y recalcula todas las actividades del proyecto "{selectedProject.name}" con los nuevos valores.</p>
                    </button>
                     <button 
                        onClick={() => { onSaveChanges(localLibrary, originalLibrary, 'global'); setIsConfirmSaveOpen(false); }}
                        className="w-full text-left p-3 border rounded-lg hover:bg-slate-100 hover:border-slate-400 transition-colors"
                    >
                        <p className="font-semibold text-slate-700">Guardar Solo Globalmente</p>
                        <p className="text-xs text-slate-600">Guarda los cambios en la biblioteca solo para futuros cálculos. El proyecto actual no se modificará.</p>
                    </button>
                    <button 
                        onClick={() => { onSaveChanges(localLibrary, originalLibrary, 'project_only_update'); setIsConfirmSaveOpen(false); }}
                        className="w-full text-left p-3 border rounded-lg hover:bg-yellow-50 hover:border-yellow-400 transition-colors disabled:opacity-50 disabled:hover:bg-transparent disabled:cursor-not-allowed"
                        disabled={!isPriceOnlyChange}
                        title={!isPriceOnlyChange ? "Esta opción solo está disponible cuando únicamente se modifican precios existentes en la mano de obra." : ""}
                    >
                        <p className="font-semibold text-yellow-700">Actualizar Precios Solo en este Proyecto</p>
                        <p className="text-xs text-slate-600">Actualiza los precios de las actividades de mano de obra coincidentes solo en este proyecto, sin cambiar la biblioteca global.</p>
                    </button>
                 </div>
                 <div className="flex justify-end mt-6">
                    <button onClick={() => setIsConfirmSaveOpen(false)} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300">Cancelar</button>
                 </div>
            </div>
        )
    }

    return (
        <div className="w-full">
            <div className="border-b mb-4">
                <nav className="-mb-px flex gap-x-6" aria-label="Tabs">
                    <button
                        onClick={() => setActiveTab('labor')}
                        className={`${
                            activeTab === 'labor'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-3 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Mano de Obra
                    </button>
                    <button
                        onClick={() => setActiveTab('formulas')}
                        className={`${
                            activeTab === 'formulas'
                                ? 'border-cyan-500 text-cyan-600'
                                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                        } whitespace-nowrap py-3 px-2 border-b-2 font-medium text-sm transition-colors`}
                    >
                        Fórmulas de Materiales
                    </button>
                </nav>
            </div>
            <div className="min-h-[60vh]">
                {activeTab === 'labor' && <DataLibraryLabor data={localLibrary.labor_activities} onUpdate={handleLaborUpdate} />}
                {activeTab === 'formulas' && <DataLibraryFormulas data={localLibrary} onUpdate={handleLocalUpdate} />}
            </div>
             <div className="flex justify-end items-center gap-4 mt-4 pt-4 border-t">
                <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-200 text-slate-700 rounded-md hover:bg-slate-300 transition-colors">Cerrar</button>
                <button 
                    type="button" 
                    onClick={handleAttemptSave} 
                    className="px-4 py-2 bg-cyan-600 text-white rounded-md hover:bg-cyan-700 transition-colors shadow disabled:bg-slate-400 disabled:cursor-not-allowed"
                    disabled={!isDirty}
                >
                    Guardar Cambios
                </button>
            </div>
            <Modal isOpen={isConfirmSaveOpen} onClose={() => setIsConfirmSaveOpen(false)} title="Confirmar Cambios">
                {renderSaveConfirmation()}
            </Modal>
        </div>
    );
};

export default DataLibrary;