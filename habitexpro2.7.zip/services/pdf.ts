import type { 
    Project, 
    Activity, 
    Material, 
    LaborItem, 
    BudgetItem,
    Transaction
} from '../types';
import { TransactionType } from '../types';

declare const jspdf: any;

export const exportProjectToPDF = (
    project: Project,
    activities: Activity[],
    totalMaterials: Material[],
    materialGrandTotal: number,
    laborItems: LaborItem[],
    laborGrandTotal: number,
    budgetItems: BudgetItem[],
    budgetGrandTotal: number,
    transactions: Transaction[],
    exchangeRate: number
): void => {
    const { jsPDF } = jspdf;
    const doc = new jsPDF();
    
    // Financial Summary
    const totalIncome = transactions.filter(t => t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = transactions.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0);
    const balance = totalIncome - totalExpense;

    const materialGrandTotalUSD = materialGrandTotal / exchangeRate;
    const laborGrandTotalUSD = laborGrandTotal / exchangeRate;
    const budgetGrandTotalUSD = budgetGrandTotal / exchangeRate;
    const projectGrandTotalCUP = materialGrandTotal + laborGrandTotal + budgetGrandTotal;
    const projectGrandTotalUSD = projectGrandTotalCUP / exchangeRate;

    doc.setFontSize(20);
    doc.text(`Reporte de Proyecto: ${project.name}`, 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Fecha de generación: ${new Date().toLocaleDateString()}`, 14, 30);

    // Grand Summary
    doc.setFontSize(16);
    doc.text('Resumen General del Proyecto', 14, 45);
    (doc as any).autoTable({
        startY: 50,
        head: [['Concepto', 'Monto (CUP)', 'Monto (USD)']],
        body: [
            [{ content: '--- Presupuesto Planificado ---', colSpan: 3, styles: { fontStyle: 'bold', fillColor: '#f1f5f9' } }],
            ['Costo de Materiales (Plan)', `$${materialGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, `$${materialGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`],
            ['Costo de Mano de Obra (Plan)', `$${laborGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, `$${laborGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`],
            ['Costo de Otros Gastos (Plan)', `$${budgetGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, `$${budgetGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`],
             [{ content: 'COSTO TOTAL (PLAN)', styles: { fontStyle: 'bold' } }, 
              { content: `$${projectGrandTotalCUP.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, styles: { fontStyle: 'bold' } },
              { content: `$${projectGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, styles: { fontStyle: 'bold' } }],
            [{ content: '--- Finanzas Reales ---', colSpan: 3, styles: { fontStyle: 'bold', fillColor: '#f1f5f9' } }],
            ['Total Ingresado', `$${totalIncome.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, `$${(totalIncome / exchangeRate).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`],
            ['Total Gastado', `$${totalExpense.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, `$${(totalExpense / exchangeRate).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`],
        ],
        foot: [
            [{ content: 'BALANCE ACTUAL', styles: { fontStyle: 'bold' } }, 
             { content: `$${balance.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, styles: { fontStyle: 'bold' } },
             { content: `$${(balance / exchangeRate).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`, styles: { fontStyle: 'bold' } }]
        ],
        theme: 'grid',
        headStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
        footStyles: { fillColor: [220, 220, 220], textColor: [33, 33, 33] },
        didParseCell: (data: any) => {
            if (data.row.section === 'body' && (data.cell.text[0].includes('---') || data.cell.text[0].includes('COSTO TOTAL'))) {
                data.cell.styles.halign = 'center';
            }
        }
    });

    // Transactions Summary Table
    if(transactions.length > 0) {
        doc.addPage();
        doc.setFontSize(16);
        doc.text('Historial de Transacciones', 14, 20);
        (doc as any).autoTable({
            startY: 25,
            head: [['Fecha', 'Tipo', 'Descripción', 'Categoría', 'Monto (CUP)']],
            body: transactions.map(t => [
                new Date(t.date).toLocaleDateString(),
                t.type,
                t.description,
                t.category || '-',
                (t.type === TransactionType.INCOME ? '+' : '-') + t.amount.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
            ]),
            theme: 'grid',
            headStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
        });
    }


    // Materials Summary Table
    doc.addPage();
    doc.setFontSize(16);
    doc.text('Resumen de Materiales', 14, 20);
    (doc as any).autoTable({
        startY: 25,
        head: [['Material', 'Cantidad', 'Unidad', 'Precio Unit. (CUP)', 'Precio Total (CUP)']],
        body: totalMaterials.map(m => [
            m.name,
            m.quantity.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            m.unit,
            (m.unitPrice || 0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            (m.quantity * (m.unitPrice || 0)).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
        ]),
        foot: [
            [{ content: 'Total Materiales (CUP)', colSpan: 4, styles: { halign: 'right', fontStyle: 'bold' } }, { content: materialGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }],
            [{ content: 'Total Materiales (USD)', colSpan: 4, styles: { halign: 'right', fontStyle: 'bold' } }, { content: materialGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }]
        ],
        theme: 'grid',
        headStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
        footStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
    });

    // Labor Summary Table
    doc.addPage();
    doc.setFontSize(16);
    doc.text('Resumen de Mano de Obra', 14, 20);
     (doc as any).autoTable({
        startY: 25,
        head: [['Actividad', 'Cantidad', 'Unidad', 'Precio Unit. (CUP)', 'Subtotal (CUP)']],
        body: laborItems.map(item => [
            item.name,
            item.quantity.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            item.unit,
            item.unitPrice.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            (item.quantity * item.unitPrice).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})
        ]),
        foot: [
            [{ content: 'Total Mano de Obra (CUP)', colSpan: 4, styles: { halign: 'right', fontStyle: 'bold' } }, { content: laborGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }],
            [{ content: 'Total Mano de Obra (USD)', colSpan: 4, styles: { halign: 'right', fontStyle: 'bold' } }, { content: laborGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }]
        ],
        theme: 'grid',
        headStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
        footStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
    });

    // Budget Summary Table
    if (budgetItems.length > 0) {
        doc.addPage();
        doc.setFontSize(16);
        doc.text('Resumen de Otros Gastos (Plan)', 14, 20);
        (doc as any).autoTable({
            startY: 25,
            head: [['Categoría', 'Descripción', 'Costo (CUP)']],
            body: budgetItems.map(item => [
                item.category,
                item.name,
                item.cost.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}),
            ]),
            foot: [
                [{ content: 'Total Otros Gastos (CUP)', colSpan: 2, styles: { halign: 'right', fontStyle: 'bold' } }, { content: budgetGrandTotal.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }],
                [{ content: 'Total Otros Gastos (USD)', colSpan: 2, styles: { halign: 'right', fontStyle: 'bold' } }, { content: budgetGrandTotalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}), styles: { halign: 'right', fontStyle: 'bold' } }]
            ],
            theme: 'grid',
            headStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
            footStyles: { fillColor: [240, 240, 240], textColor: [33, 33, 33] },
        });
    }

    doc.save(`Habitex_Calcula_${project.name.replace(/\s/g, '_')}_${new Date().toISOString().slice(0,10)}.pdf`);
};
