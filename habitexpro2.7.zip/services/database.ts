import type { 
    Project, 
    Activity, 
    LaborItem, 
    BudgetItem, 
    Transaction
} from '../types';
import { 
    PREDEFINED_LABOR_ACTIVITIES, HORMIGONES_DATA, ACERO_BARRAS_DATA, MORTEROS_MUROS_DATA,
    MORTEROS_REVESTIMIENTO_DATA, MORTEROS_PISO_DATA, PINTURA_DATA, ENCHAPE_DATA,
    PLADUR_PARED_DATA, PLADUR_TECHO_DATA
} from '../constants';

declare const idb: any;
const { openDB } = idb; // Use global idb from CDN

const DB_NAME = 'habitex-calcula-db';
const DB_VERSION = 6; // Incremented version for new data library
const PROJECTS_STORE = 'projects';
const ACTIVITIES_STORE = 'activities';
const MATERIAL_PRICES_STORE = 'material_prices';
const LABOR_ITEMS_STORE = 'labor_items';
const BUDGET_ITEMS_STORE = 'budget_items';
const TRANSACTIONS_STORE = 'transactions';
const DATA_LIBRARY_STORE = 'data_library';

const ALL_STORES = [
    PROJECTS_STORE, 
    ACTIVITIES_STORE, 
    MATERIAL_PRICES_STORE, 
    LABOR_ITEMS_STORE, 
    BUDGET_ITEMS_STORE, 
    TRANSACTIONS_STORE,
    DATA_LIBRARY_STORE,
];


let dbPromise: any;

const initDB = () => {
    if (!dbPromise) {
        dbPromise = openDB(DB_NAME, DB_VERSION, {
            upgrade(db: any, oldVersion: number) {
                 if (oldVersion < 1) {
                    if (!db.objectStoreNames.contains(PROJECTS_STORE)) {
                        const projectStore = db.createObjectStore(PROJECTS_STORE, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                        projectStore.createIndex('name', 'name');
                    }
                    if (!db.objectStoreNames.contains(ACTIVITIES_STORE)) {
                        const activityStore = db.createObjectStore(ACTIVITIES_STORE, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                        activityStore.createIndex('projectId', 'projectId');
                    }
                }
                if (oldVersion < 2) {
                    if (!db.objectStoreNames.contains(MATERIAL_PRICES_STORE)) {
                        db.createObjectStore(MATERIAL_PRICES_STORE, { keyPath: ['name', 'unit'] });
                    }
                }
                if (oldVersion < 3) {
                    if (!db.objectStoreNames.contains(LABOR_ITEMS_STORE)) {
                         const laborStore = db.createObjectStore(LABOR_ITEMS_STORE, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                        laborStore.createIndex('projectId', 'projectId');
                    }
                }
                if (oldVersion < 4) {
                    if (!db.objectStoreNames.contains(BUDGET_ITEMS_STORE)) {
                         const budgetStore = db.createObjectStore(BUDGET_ITEMS_STORE, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                        budgetStore.createIndex('projectId', 'projectId');
                    }
                }
                if (oldVersion < 5) {
                    if (!db.objectStoreNames.contains(TRANSACTIONS_STORE)) {
                         const transactionStore = db.createObjectStore(TRANSACTIONS_STORE, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                        transactionStore.createIndex('projectId', 'projectId');
                    }
                }
                if (oldVersion < 6) {
                    if (!db.objectStoreNames.contains(DATA_LIBRARY_STORE)) {
                        db.createObjectStore(DATA_LIBRARY_STORE, { keyPath: 'id' });
                    }
                }
            },
        });
    }
    return dbPromise;
};

// Data Library functions
export const initDataLibrary = async () => {
    const db = await initDB();
    const count = await db.count(DATA_LIBRARY_STORE);
    if (count === 0) {
        console.log('Initializing Data Library...');
        const tx = db.transaction(DATA_LIBRARY_STORE, 'readwrite');
        try {
            await Promise.all([
                tx.store.put({ id: 'labor_activities', data: PREDEFINED_LABOR_ACTIVITIES }),
                tx.store.put({ id: 'hormigones', data: HORMIGONES_DATA }),
                tx.store.put({ id: 'acero_barras', data: ACERO_BARRAS_DATA }),
                tx.store.put({ id: 'morteros_muros', data: MORTEROS_MUROS_DATA }),
                tx.store.put({ id: 'morteros_revestimiento', data: MORTEROS_REVESTIMIENTO_DATA }),
                tx.store.put({ id: 'morteros_piso', data: MORTEROS_PISO_DATA }),
                tx.store.put({ id: 'pintura', data: PINTURA_DATA }),
                tx.store.put({ id: 'enchape', data: ENCHAPE_DATA }),
                tx.store.put({ id: 'pladur_pared', data: PLADUR_PARED_DATA }),
                tx.store.put({ id: 'pladur_techo', data: PLADUR_TECHO_DATA }),
            ]);
            await tx.done;
            console.log('Data Library initialized successfully.');
        } catch (error) {
            console.error('Failed to initialize data library:', error);
            tx.abort();
        }
    }
};

export const getDataLibrary = async (): Promise<Record<string, any>> => {
    const db = await initDB();
    const allItems = await db.getAll(DATA_LIBRARY_STORE);
    return allItems.reduce((acc: Record<string, any>, item: { id: string; data: any }) => {
        acc[item.id] = item.data;
        return acc;
    }, {});
};

export const updateDataLibraryItem = async (id: string, data: any) => {
    const db = await initDB();
    return db.put(DATA_LIBRARY_STORE, { id, data });
};

// Project functions
export const getProjects = async (): Promise<Project[]> => {
    const db = await initDB();
    return db.getAll(PROJECTS_STORE);
};

export const addProject = async (project: Project) => {
    const db = await initDB();
    return db.add(PROJECTS_STORE, project);
};

export const updateProject = async (project: Project) => {
    const db = await initDB();
    return db.put(PROJECTS_STORE, project);
}

export const deleteProject = async (id: number) => {
    const db = await initDB();
    const tx = db.transaction(ALL_STORES, 'readwrite');
    
    const activityStore = tx.objectStore(ACTIVITIES_STORE);
    const projectActivities = await activityStore.index('projectId').getAll(id);
    await Promise.all(projectActivities.map((act: Activity) => activityStore.delete(act.id)));
    
    const laborStore = tx.objectStore(LABOR_ITEMS_STORE);
    const projectLaborItems = await laborStore.index('projectId').getAll(id);
    await Promise.all(projectLaborItems.map((item: LaborItem) => laborStore.delete(item.id)));
    
    const budgetStore = tx.objectStore(BUDGET_ITEMS_STORE);
    const projectBudgetItems = await budgetStore.index('projectId').getAll(id);
    await Promise.all(projectBudgetItems.map((item: BudgetItem) => budgetStore.delete(item.id)));

    const transactionStore = tx.objectStore(TRANSACTIONS_STORE);
    const projectTransactions = await transactionStore.index('projectId').getAll(id);
    await Promise.all(projectTransactions.map((item: Transaction) => transactionStore.delete(item.id)));

    await tx.objectStore(PROJECTS_STORE).delete(id);
    await tx.done;
};

// Activity functions
export const getActivities = async (projectId: number): Promise<Activity[]> => {
    const db = await initDB();
    return db.getAllFromIndex(ACTIVITIES_STORE, 'projectId', projectId);
};

export const addActivity = async (activity: Activity) => {
    const db = await initDB();
    return db.add(ACTIVITIES_STORE, activity);
};

export const updateActivity = async (activity: Activity) => {
    const db = await initDB();
    return db.put(ACTIVITIES_STORE, activity);
}

export const deleteActivity = async (id: number) => {
    const db = await initDB();
    return db.delete(ACTIVITIES_STORE, id);
};

// Material Price functions
export const getMaterialPrices = async () => {
    const db = await initDB();
    return db.getAll(MATERIAL_PRICES_STORE);
};

export const setMaterialPrice = async (priceData: { name: string, unit: string, price: number }) => {
    const db = await initDB();
    return db.put(MATERIAL_PRICES_STORE, priceData);
};

// Labor Item functions
export const getLaborItems = async (projectId: number): Promise<LaborItem[]> => {
    const db = await initDB();
    return db.getAllFromIndex(LABOR_ITEMS_STORE, 'projectId', projectId);
};

export const addLaborItem = async (item: LaborItem) => {
    const db = await initDB();
    return db.add(LABOR_ITEMS_STORE, item);
};

export const updateLaborItem = async (item: LaborItem) => {
    const db = await initDB();
    return db.put(LABOR_ITEMS_STORE, item);
}

export const deleteLaborItem = async (id: number) => {
    const db = await initDB();
    return db.delete(LABOR_ITEMS_STORE, id);
};

// Budget Item functions
export const getBudgetItems = async (projectId: number): Promise<BudgetItem[]> => {
    const db = await initDB();
    return db.getAllFromIndex(BUDGET_ITEMS_STORE, 'projectId', projectId);
};

export const addBudgetItem = async (item: BudgetItem) => {
    const db = await initDB();
    return db.add(BUDGET_ITEMS_STORE, item);
};

export const updateBudgetItem = async (item: BudgetItem) => {
    const db = await initDB();
    return db.put(BUDGET_ITEMS_STORE, item);
}

export const deleteBudgetItem = async (id: number) => {
    const db = await initDB();
    return db.delete(BUDGET_ITEMS_STORE, id);
};

// Transaction functions
export const getTransactions = async (projectId: number): Promise<Transaction[]> => {
    const db = await initDB();
    return db.getAllFromIndex(TRANSACTIONS_STORE, 'projectId', projectId);
};

export const addTransaction = async (item: Transaction) => {
    const db = await initDB();
    return db.add(TRANSACTIONS_STORE, item);
};

export const updateTransaction = async (item: Transaction) => {
    const db = await initDB();
    return db.put(TRANSACTIONS_STORE, item);
};

export const deleteTransaction = async (id: number) => {
    const db = await initDB();
    return db.delete(TRANSACTIONS_STORE, id);
};

// Data Export/Import
export const exportAllData = async () => {
    const db = await initDB();
    const tx = db.transaction(ALL_STORES, 'readonly');
    const [projects, activities, materialPrices, laborItems, budgetItems, transactions, dataLibrary] = await Promise.all([
        tx.objectStore(PROJECTS_STORE).getAll(),
        tx.objectStore(ACTIVITIES_STORE).getAll(),
        tx.objectStore(MATERIAL_PRICES_STORE).getAll(),
        tx.objectStore(LABOR_ITEMS_STORE).getAll(),
        tx.objectStore(BUDGET_ITEMS_STORE).getAll(),
        tx.objectStore(TRANSACTIONS_STORE).getAll(),
        tx.objectStore(DATA_LIBRARY_STORE).getAll(),
    ]);
    await tx.done;
    return { projects, activities, materialPrices, laborItems, budgetItems, transactions, dataLibrary };
};

export const importAllData = async (data: any) => {
    const db = await initDB();
    const tx = db.transaction(ALL_STORES, 'readwrite');
    
    // Create a map to track old project IDs to new ones
    const oldToNewProjectIds: { [key: number]: number } = {};

    // Process projects
    for (const project of data.projects) {
        if (project.id !== undefined) {
            const oldId = project.id;
            delete project.id; // Remove old ID so IndexedDB can auto-generate a new one
            const newId = await tx.objectStore(PROJECTS_STORE).add(project);
            oldToNewProjectIds[oldId] = newId;
        } else {
            await tx.objectStore(PROJECTS_STORE).add(project); // Handle projects without an ID just in case
        }
    }

    // Process activities, mapping to new project IDs
    for (const activity of data.activities) {
        const newProjectId = oldToNewProjectIds[activity.projectId];
        if (newProjectId) {
            activity.projectId = newProjectId;
            delete activity.id; // Remove old ID for auto-generation
            await tx.objectStore(ACTIVITIES_STORE).add(activity);
        }
    }

    // Process labor items, mapping to new project IDs
    for (const laborItem of data.laborItems) {
        const newProjectId = oldToNewProjectIds[laborItem.projectId];
        if (newProjectId) {
            laborItem.projectId = newProjectId;
            delete laborItem.id; // Remove old ID for auto-generation
            await tx.objectStore(LABOR_ITEMS_STORE).add(laborItem);
        }
    }

    // Process budget items, mapping to new project IDs
    if (data.budgetItems) {
        for (const budgetItem of data.budgetItems) {
            const newProjectId = oldToNewProjectIds[budgetItem.projectId];
            if (newProjectId) {
                budgetItem.projectId = newProjectId;
                delete budgetItem.id; // Remove old ID for auto-generation
                await tx.objectStore(BUDGET_ITEMS_STORE).add(budgetItem);
            }
        }
    }
    
    // Process transactions, mapping to new project IDs
    if (data.transactions) {
        for (const transaction of data.transactions) {
            const newProjectId = oldToNewProjectIds[transaction.projectId];
            if (newProjectId) {
                transaction.projectId = newProjectId;
                delete transaction.id; // Remove old ID for auto-generation
                await tx.objectStore(TRANSACTIONS_STORE).add(transaction);
            }
        }
    }

    // Process material prices using 'put' to add or update
    for (const materialPrice of data.materialPrices) {
        await tx.objectStore(MATERIAL_PRICES_STORE).put(materialPrice);
    }

    // Overwrite data library with imported data
    if (data.dataLibrary && Array.isArray(data.dataLibrary)) {
        for (const item of data.dataLibrary) {
            await tx.objectStore(DATA_LIBRARY_STORE).put(item);
        }
    }


    await tx.done;
};